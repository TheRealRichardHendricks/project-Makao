﻿using System;
using System.Collections.Generic;
using TIG.AV.Karte;

namespace MakaoBenchmark
{
    public class Move : IMove
    {
        #region Atributes

        float value; // vrednost za heuristiku
        TipPoteza tip;
        List<Karta> karte;
        Boja novaBoja;

        #endregion

        #region Constructors

        public Move()
        {
            value = 0;
            karte = new List<Karta>();
        }

        public Move(float value)
        {
            this.value = value;
            karte = new List<Karta>();
        }


        #endregion

        #region Properties

        public TipPoteza Tip { get { return tip; } set { tip = value; } }
        public List<Karta> Karte { get { return karte; } set { karte = value; } }
        public Boja NovaBoja { get { return novaBoja; } set { novaBoja = value; } }
        public float Value { get { return this.value; } set { this.value = value; } }

        #endregion

        #region Benchmark

        public void PrintPotez()
        {
            Console.WriteLine();
            Console.WriteLine("---> Potez: " + tip.ToString());
            foreach (Karta k in karte)
            {
                Console.Write(k.Broj + " " + k.Boja + " | ");
            }
            Console.WriteLine("BIRAM NOVU BOJU: " + novaBoja.ToString());
            Console.WriteLine("Vrednost: " + value);
        }

        #endregion


    }
}

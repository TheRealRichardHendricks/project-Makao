﻿using System;
using TIG.AV.Karte;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace MakaoBenchmark
{
    public class IgracAI : IIgra
    {
        public const int MAX_SEARCHING_DEPTH = 3;

        #region Athributes

        private readonly GameContext context;
        //Task iterative;
        //object locker;

        #endregion

        #region Constructors

        public IgracAI()
        {
            Ime = "ComputerPlayer";
            context = new GameContext();
        }

        public IgracAI(string ime)
        {
            Ime = ime;
            context = new GameContext();
        }

        #endregion

        #region Properties

        public string Ime { get; set; }
        public IMove BestMove { get; set; }

        #endregion

        public void SetRuka(List<Karta> karte)
        {
            context.DodajKarteURuku(karte);
        }


        public void BeginBestMove()
        {

            if (context.Zadnja.Broj == "2" && context.Zadnja.Boja == Boja.Tref)
            {
                Move potez = new Move { Tip = TipPoteza.KupiKazneneKarte | TipPoteza.KrajPoteza };
                BestMove = potez;
            }
            else if (context.Zadnja.Broj == "7")
            {
                foreach (Karta karta in context.Ruka)
                {
                    if (karta.Broj == "7")
                    {
                        Move potez1 = new Move();
                        potez1.Tip = TipPoteza.BacaKartu | TipPoteza.KrajPoteza;
                        potez1.Karte.Add(karta);
                        BestMove = potez1;
                        return;
                    }
                }
                Move potez = new Move();
                potez.Tip = TipPoteza.KupiKazneneKarte | TipPoteza.KrajPoteza;
                BestMove = potez;
            }
            else
            {
                IterativeDeephing();
                //BestMove = context.AlfaBeta(context, float.MinValue, float.MaxValue, MAX_SEARCHING_DEPTH, true);
            }



            //lock (locker)
            //{
            //  locker = false;
            //}
            //iterative = Task.Run(() =>
            //{
            //  IterativeDephing();
            //});


        }

        //protected virtual void IterativeDephing()
        //{
        //    int s = 1;
        //    while (true)
        //    {
        //        IMove move = context.AlfaBeta(context, float.MinValue, float.MaxValue, s, true);
        //        Console.WriteLine(s);
        //        s++;
        //    }


        //    //lock (locker)
        //    //{
        //    //    if ((bool)locker)
        //    //        return;
        //    //    // BestMove = move;
        //    //}

        //}

        protected virtual void IterativeDeephing()
        {
            Task taskA = Task.Run(() =>
            {
                int dubina = 1;
                while(true){
                    BestMove = context.AlfaBeta(context, float.MinValue, float.MaxValue, dubina, true);
                    dubina++;
                    Thread.Sleep(1);  
                }

            });
            try
            {
                // Ovaj deo koda je npotreban jer task nikada nece biti gotov, prekida se spolja pozivom EndBestMove

                /* bool completed = taskA.IsCompleted;
                Console.WriteLine("Task A completed: {0}, Status: {1}", completed, taskA.Status);
                if (!completed)
                    Console.WriteLine("Timed out before task A completed.");  */ 
            }
            catch (AggregateException)
            {
                Console.WriteLine("Exception in taskA.");
            }
        }




public void EndBestMove()
        {
            //lock (locker)
            //{
            //    locker = true;
            //}

            Console.WriteLine("BEST MOVE: {0}", BestMove);
            Console.WriteLine();
            Console.WriteLine("---> Potez: " + BestMove.Tip.ToString());
            foreach (Karta k in BestMove.Karte)
            {
                Console.Write(k.Broj + " " + k.Boja + " | ");
            }
            Console.WriteLine("BIRAM NOVU BOJU: " + BestMove.NovaBoja);
            Console.WriteLine("Vrednost: " + (BestMove as Move).Value);

        }



        public void KupioKarte(List<Karta> karte)
        {
            context.DodajKarteURuku(karte);
        }

        public void Bacenekarte(List<Karta> karte, Boja boja, int BrojKarataProtivnika)
        {
            if (karte.Count == 0)
                return;

            context.ProtivnikovPotez(karte);
            context.ProtivnikoveKarte = BrojKarataProtivnika;  // jos koliko mu je ostalo u ruci
            // ako je trazio zandarom neki znak
            if (boja != Boja.Unknown)
                context.NovaBoja = boja;
        }

        public void Reset()
        {
            context.Reset();
        }

        public void StampajRuku()
        {
            context.StampajRuku(this);
        }



        #region Benchmark

        public void SetTalon(Karta k)
        {
            context.Talon.Add(k);
            context.Zadnja = k;

            for (int i = context.PreostaleKarte.Count - 1; i >= 0; i--)
            {
                if (context.PreostaleKarte.ElementAt(i).Boja == k.Boja && context.PreostaleKarte.ElementAt(i).Broj == k.Broj)
                    context.PreostaleKarte.ElementAt(i);
            }
        }

        public void TesitrajBrzinu()
        {
            var stoperica = System.Diagnostics.Stopwatch.StartNew();

            if (context.Zadnja.Broj == "2" && context.Zadnja.Boja == Boja.Tref)
            {
                Move potez = new Move { Tip = TipPoteza.KupiKazneneKarte | TipPoteza.KrajPoteza };
                potez.PrintPotez();
                BestMove = potez;
            }
            else if (context.Zadnja.Broj == "7")
            {
                foreach (Karta karta in context.Ruka)
                {
                    if (karta.Broj == "7")
                    {
                        Move potez1 = new Move();
                        potez1.Tip = TipPoteza.BacaKartu | TipPoteza.KrajPoteza;
                        potez1.Karte.Add(karta);
                        potez1.PrintPotez();
                        BestMove = potez1;
                        return;
                    }
                }
                Move potez = new Move();
                potez.Tip = TipPoteza.KupiKazneneKarte | TipPoteza.KrajPoteza;
                potez.PrintPotez();
                BestMove = potez;
            }
            else
            {
                BestMove = context.AlfaBeta(context, float.MinValue, float.MaxValue, MAX_SEARCHING_DEPTH, true);
                stoperica.Stop();
                long brojMILISEKUNDI = stoperica.ElapsedMilliseconds;
                Console.WriteLine("Potrebno je: " + brojMILISEKUNDI + " milisekundi!");

            }

        }


        #endregion

    };


    public class IgracHuman
    {
        // ovde ide impelementacija za igraca kojeg ce kontrolisati krajnji korisnik
    }
}

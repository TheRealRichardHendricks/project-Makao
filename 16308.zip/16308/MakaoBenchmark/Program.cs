﻿using System;
using System.Collections.Generic;
using TIG.AV.Karte;

namespace MakaoBenchmark
{
    public class Program
    {
        public static void Main(string[] args)
        {
            IgracAI igrac = new IgracAI();
            Karta karta = new Karta();
            karta.Boja = Boja.Tref;
            karta.Broj = "7";

            Karta karta1 = new Karta();
            karta1.Boja = Boja.Herz;
            karta1.Broj = "9";
            Karta karta2 = new Karta();
            karta2.Boja = Boja.Pik;
            karta2.Broj = "J";
            Karta karta3 = new Karta();
            karta3.Boja = Boja.Karo;
            karta3.Broj = "7";

            List<Karta> l = new List<Karta>();
            l.Add(karta1);
            l.Add(karta2);
            l.Add(karta3);
            igrac.SetRuka(l);
            igrac.SetTalon(karta);
            Console.WriteLine("Na talonu je: " + karta.Broj + " " + karta.Boja);
            igrac.StampajRuku();
            Console.WriteLine("Spremi potez");
            igrac.BeginBestMove();
            Console.ReadLine(); // nakon 1s 
            igrac.EndBestMove();
        }
    }
}

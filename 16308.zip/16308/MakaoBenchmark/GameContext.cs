﻿using System;
using System.Collections.Generic;
using System.Linq;
using TIG.AV.Karte;

namespace MakaoBenchmark
{
    internal class GameContext
    {
        #region Attributes

        private List<Karta> ruka;            // karte koje su kod mene u ruci
        private List<Karta> talon;           // stek karata koje su do sada izbacene
        private List<Karta> preostaleKarte;  // u spilu ili kod protivnika u ruci
        private int protivnikoveKarte;       // koliko je karata ostalo protivniku u ruci
        private Karta zadnja;                // trenutno na talonu

        // ovo je za benchmark
        static public List<Karta> deck;

        #endregion

        #region Constructors

        public GameContext()
        {
            ruka = new List<Karta>();
            talon = new List<Karta>();
            preostaleKarte = new List<Karta>();
     
            deck = new List<Karta>(52);
            deck = PodeliKarteIzSpila();
            foreach (Karta k in deck)
            {
                preostaleKarte.Add(k);
            }
            protivnikoveKarte = 6;
        }

        public GameContext(GameContext trenutni, Move potez, bool maximizingPlayer)
        {
            ruka = new List<Karta>();
            talon = new List<Karta>();
            preostaleKarte = new List<Karta>();
            zadnja = new Karta();
            // protivnikoveKarte = 6;
            deck = new List<Karta>(52);
            deck = PodeliKarteIzSpila();


            Karta Kopiraj(Karta k)  // kad ulazim u svaku granu alfa betom ne smem da diram originalne postavke...zato se karte kopiraju
            {
                Karta kopija = new Karta
                {
                    Broj = k.Broj,
                    Boja = k.Boja
                };
                return kopija;
            }
            foreach (Karta karta in trenutni.ruka)
            {
                ruka.Add(Kopiraj(karta));
            }
            foreach (Karta karta in trenutni.talon)
            {
                talon.Add(Kopiraj(karta));
            }
            foreach (Karta karta in trenutni.preostaleKarte)
            {
                preostaleKarte.Add(Kopiraj(karta));
            }


            foreach (Karta karta in potez.Karte) 
            {
                if (!maximizingPlayer) // provera da li u alfa beti igra max ili min player
                {
                    for (int i = preostaleKarte.Count - 1; i >= 0; i--)
                    {
                        if (preostaleKarte.ElementAt(i).Boja == karta.Boja && preostaleKarte.ElementAt(i).Broj == karta.Broj)
                            preostaleKarte.RemoveAt(i);  
                    }
                }
                else
                {
                    for (int i = ruka.Count - 1; i >= 0; i--)
                    {
                        if (ruka.ElementAt(i).Boja == karta.Boja && ruka.ElementAt(i).Broj == karta.Broj)
                            ruka.RemoveAt(i);
                    }
                }
                talon.Add(karta); // baca kartu na talon (hipoteticki)
            }
            // i sad je to zadnja
            zadnja.Boja = talon.Last().Boja;  
            zadnja.Broj = talon.Last().Broj;
        }
        #endregion

        #region Properties
        public int ProtivnikoveKarte { get { return protivnikoveKarte; } set { protivnikoveKarte = value; } }
        public Boja NovaBoja { get; set; }
        public List<Karta> Talon { get { return talon; } }
        public List<Karta> Ruka { get { return ruka; } }
        public Karta Zadnja { get { return zadnja; } set { zadnja = value; }}
        public List<Karta> PreostaleKarte { get { return preostaleKarte; } set { preostaleKarte = value; }}
        #endregion

        #region Algorithms


        /// <summary>
        /// Alfa-Beta algoritam
        /// pseudo kod: https://en.wikipedia.org/wiki/Alpha–beta_pruning
        /// </summary>
        /// <returns> Vrednost najboljeg poteza </returns>
        /// <param name="thisContext"> Trenutni Game Context </param>
        /// <param name="minValue"> Minus beskonacno </param>
        /// <param name="maxValue"> Plus beskonacno </param>
        /// <param name="dubina"> Max dubina do koje ce se vrsiti pretraga </param>
        /// <param name="maximizingPlayer">If set to <c>true</c> Ja sam na potezu! </param>
        /// 
        public Move AlfaBeta(GameContext thisContext, float minValue, float maxValue, int dubina, bool maximizingPlayer)
        {
            float terminalniCvor = thisContext.Kraj();

            /*  if depth = 0 or node is a terminal node then
             *      return the heuristic value of node 
             */
            if (dubina == 0)
            {
                float vrednostPoteza = thisContext.Evaluacija();
                return new Move(vrednostPoteza);
            }
            else if (terminalniCvor == float.MinValue || terminalniCvor == float.MaxValue)
                return new Move(terminalniCvor);

            /* if maximizingPlayer then
             *      value := −∞
             *      for each child of node do
             *          value := max(value, alphabeta(child, depth − 1, α, β, FALSE))
             *          α := max(α, value)
             *          if α ≥ β then
             *              break (* β cut-off *)
             * return value
             */
            if (maximizingPlayer)
            {
                Move bestMove = null;

                float vrednostPoteza = float.MinValue;
                List<Move> moguciPotezi = thisContext.MoguciPotezi();
                foreach (Move potez in moguciPotezi)
                {
                    GameContext nextContext = new GameContext(thisContext, potez, maximizingPlayer);
                    vrednostPoteza = (vrednostPoteza > AlfaBeta(nextContext, minValue, maxValue, dubina - 1, !maximizingPlayer).Value) ? vrednostPoteza : AlfaBeta(nextContext, minValue, maxValue, dubina - 1, !maximizingPlayer).Value;
                    bestMove = potez;
                    bestMove.Value = vrednostPoteza;
                    minValue = (minValue > vrednostPoteza) ? minValue : vrednostPoteza;
                    if (maxValue >= minValue)
                        break;
                }

                return bestMove;
            }
            /* else
             *  value := +∞
             *  for each child of node do
             *      value := min(value, alphabeta(child, depth − 1, α, β, TRUE))
             *      β := min(β, value)
             *      if α ≥ β then
             *          break (* α cut-off *)
             * return value
             */
            else
            {
                Move bestMove = null;

                float vrednostPoteza = float.MaxValue;
                List<Move> moguciPoteziProtivnika = thisContext.MoguciPoteziProtivnika();
                foreach (Move potez in moguciPoteziProtivnika)
                {
                    GameContext nextContext = new GameContext(thisContext, potez, !maximizingPlayer);
                    vrednostPoteza = (vrednostPoteza < AlfaBeta(nextContext, minValue, maxValue, dubina - 1, maximizingPlayer).Value) ? vrednostPoteza : AlfaBeta(nextContext, minValue, maxValue, dubina - 1, maximizingPlayer).Value;
                    bestMove = potez;
                    bestMove.Value = vrednostPoteza;
                    maxValue = (maxValue < vrednostPoteza) ? maxValue : vrednostPoteza;
                    if (maxValue >= minValue)
                        break;
                }

                return bestMove;
            }

        }

        #endregion

        #region Strategy

        // TODO Za verziju 2 poboljsaj strategiju u vezi sa kecevima...ovo sad nije dobro
        // TODO Kad kupim kartu nemoj da bude kraj poteza nego porbaj da je odigras
        // TODO Ako sam ja bacio malu dvojku ili sedmicu, i ona je ostala na talonu, sledeci moj potez nije da kupim kaznene karte
        // Ovo ostalo sljaka
        public List<Move> MoguciPotezi()
        {
            List<Move> _moguciPotezi = new List<Move>();

            SortirajRuku();
            int kolikoURuci = ruka.Count;


            if (HasMatch(zadnja))  // ako u ruci ima uopste bilo koju kartu koju moze da baci ulazi u petlju, inace ne proverava nista (bacice zandara ako ima ili ce kupiti kartu)
            {
                foreach (Karta karta in ruka)
                {
                    if (karta.Boja == zadnja.Boja || karta.Broj == zadnja.Broj)
                    {
                        Move potez = new Move();

                        if (kolikoURuci == 2)  // mora da kaze zadnja ako baci
                        {
                            switch (karta.Broj)
                            {
                                case "A":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KupiKartu | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                                case "J":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    potez.NovaBoja = IzaberiZnak();
                                    break;
                                default:
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                            }
                        }
                        else if (kolikoURuci == 1)  // mora kaze makao ako baci
                        {
                            switch (karta.Broj)
                            {
                                case "A":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KupiKartu | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                                case "J":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Makao | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    potez.NovaBoja = IzaberiZnak();
                                    break;
                                default:
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.Makao | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                            }
                        }
                        else
                        {
                            switch (karta.Broj)  // klasika
                            {
                                case "A":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KarjPotezaKupiKartu; // losa je strategija al nek stoji za sada
                                    potez.Karte.Add(karta);
                                    break;
                                case "J":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    potez.NovaBoja = IzaberiZnak();
                                    break;
                                default:
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                            }
                        }


                        _moguciPotezi.Add(potez);
                    }
                }
            }
            else if (!_moguciPotezi.Any()) 
            {
                foreach(Karta karta in ruka)
                {
                    if(karta.Broj == "J")
                    {
                        Move potez = new Move();
                        switch (kolikoURuci)
                        {
                            case 1:
                                potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Makao | TipPoteza.KrajPoteza;
                                potez.Karte.Add(karta);
                                potez.NovaBoja = IzaberiZnak();
                                break;
                            case 2:
                                potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                potez.Karte.Add(karta);
                                potez.NovaBoja = IzaberiZnak();
                                break;
                            default:
                                potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.KrajPoteza;
                                potez.Karte.Add(karta);
                                potez.NovaBoja = IzaberiZnak();
                                break;
                        }
                        _moguciPotezi.Add(potez);
                    }
                }
            }

                Move potez0 = new Move { Tip = TipPoteza.KupiKartu | TipPoteza.KrajPoteza };
                _moguciPotezi.Add(potez0);



            return _moguciPotezi;
        }

        public List<Move> MoguciPoteziProtivnika()
        {
            List<Move> _moguciPotezi = new List<Move>();


            if (HasMatchOpponent(zadnja))
            {
                foreach (Karta karta in preostaleKarte)
                {
                    if (karta.Boja == zadnja.Boja || karta.Broj == zadnja.Broj)
                    {
                        Move potez = new Move();

                        if (protivnikoveKarte == 2)  // treba da zove poslednju
                        {
                            switch (karta.Broj)
                            {
                                case "A":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KupiKartu | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                                case "J":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    potez.NovaBoja = IzaberiZnakProtivniku();
                                    break;
                                default:
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                            }
                        }
                        else if (protivnikoveKarte == 1)  // treba da zove makao
                        {
                            switch (karta.Broj)
                            {
                                case "A":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KupiKartu | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                                case "J":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Makao | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    potez.NovaBoja = IzaberiZnakProtivniku();
                                    break;
                                default:
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.Makao | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                            }
                        }
                        else // klasika
                        {
                            switch (karta.Broj)
                            {
                                case "A":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KupiKartu | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                                case "J":
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    potez.NovaBoja = IzaberiZnakProtivniku();
                                    break;
                                default:
                                    potez.Tip = TipPoteza.BacaKartu | TipPoteza.KrajPoteza;
                                    potez.Karte.Add(karta);
                                    break;
                            }
                        }

                        _moguciPotezi.Add(potez);
                    }
                }
            }
            else if (!_moguciPotezi.Any())
            {
                foreach (Karta karta in preostaleKarte)
                {
                    if (karta.Broj == "J")
                    {
                        Move potez = new Move();
                        switch (protivnikoveKarte)
                        {
                            case 1:
                                potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Makao | TipPoteza.KrajPoteza;
                                potez.Karte.Add(karta);
                                potez.NovaBoja = IzaberiZnak();
                                break;
                            case 2:
                                potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.Poslednja | TipPoteza.KrajPoteza;
                                potez.Karte.Add(karta);
                                potez.NovaBoja = IzaberiZnak();
                                break;
                            default:
                                potez.Tip = TipPoteza.BacaKartu | TipPoteza.PromeniBoju | TipPoteza.KrajPoteza;
                                potez.Karte.Add(karta);
                                potez.NovaBoja = IzaberiZnak();
                                break;
                        }
                        _moguciPotezi.Add(potez);
                    }
                }
            }
            

                Move potez0 = new Move { Tip = TipPoteza.KupiKartu | TipPoteza.KrajPoteza };
                _moguciPotezi.Add(potez0);

            

            return _moguciPotezi;

        }

        #endregion

        #region Methods

        public Boja IzaberiZnak()  // Zandar bira znak
        {
            if (!ruka.Any())
            {
                return Boja.Unknown;
            }
            var znakovi = ruka.GroupBy(x => x.Boja).OrderByDescending(x => x.Count());
            return znakovi.First().First().Boja;
        }

        public Boja IzaberiZnakProtivniku()
        {
            if (!preostaleKarte.Any())
                return Boja.Unknown;
            var znakovi = preostaleKarte.GroupBy(x => x.Boja).OrderByDescending(x => x.Count());
            return znakovi.First().First().Boja;
        }

        public bool HasMatch(Karta karta)
        {
            return ruka.Any(x => x.Boja == karta.Boja || x.Broj == karta.Broj);
        }

        public bool HasMatchOpponent(Karta karta)
        {
            return preostaleKarte.Any(x => x.Boja == karta.Boja || x.Broj == karta.Broj);
        }

        public void SortirajRuku()
        {
            ruka = ruka.OrderBy(x => x.Boja).ThenByDescending(x => x.Broj).ToList();
        }

        public float Kraj()
        {
            if (ruka.Count == 0)
                return float.MaxValue;
            else if (protivnikoveKarte == 0)
                return float.MinValue;
            return 0;
        }

        public void DodajKarteURuku(List<Karta> karte)
        {
            foreach (Karta karta in karte)
            {
                for (int i = preostaleKarte.Count - 1; i >= 0; i--)
                    if (preostaleKarte.ElementAt(i).Boja == karta.Boja && preostaleKarte.ElementAt(i).Broj == karta.Broj)
                       preostaleKarte.RemoveAt(i);
          
                ruka.Add(karta);
            }
            SortirajRuku();
        }

        public void ProtivnikovPotez(List<Karta> protivnikovPotez)
        {
            foreach (Karta karta in protivnikovPotez)
            {
                for (int i = preostaleKarte.Count - 1; i >= 0; i--)
                    if (preostaleKarte.ElementAt(i).Boja == karta.Boja && preostaleKarte.ElementAt(i).Broj == karta.Broj)
                        preostaleKarte.RemoveAt(i);

                talon.Add(karta);
            }
        }

        public void Reset()
        {
            ruka.Clear();
            ruka = new List<Karta>();
            talon.Clear();
            talon = new List<Karta>();
            preostaleKarte.Clear();
            preostaleKarte = new List<Karta>();
            deck.Clear();
            deck = new List<Karta>(52);
            deck = PodeliKarteIzSpila();
            foreach (Karta k in deck)
            {
                preostaleKarte.Add(k);
            }
            protivnikoveKarte = 6;
        }


        #endregion

        #region Evaluation Functions

        /// <summary>
        /// Vrsi evaluaciju svih mogucih poteza kako bi dosao do BestMove-a
        /// Trenutno radi najosnovniju stvar a to je da samo sumira vrednosti poteza
        /// i vraca onaj sa najvecom sumom, odnosno najvecom dubinom stabla (da bi
        /// mogao kasnije da se izbacam, a ne da kupujem karte). Ovo za version 2
        /// treba doraditi tako da ispostuje strategiju.
        /// </summary>
        /// <returns> Vrednost najboljeg poteza </returns>
        public float Evaluacija()
        {
            float suma = 0;
            foreach (Karta karta in ruka)
            {
                // cilj je da se izbacamo od stihova ka najmanje vrednim kartama
                if (float.TryParse(karta.Broj, out float vrednostKarte)) // kovertuje string karta.Broj u float broj sa konkretnom vrednoscu
                    suma += vrednostKarte;
                else
                    suma += Char.Parse(karta.Broj);
            }
            return -suma; // zbog alfa-beta
        }


        #endregion




        /// <summary>
        /// Sve funkcionalnosti koje treba implementirati ili dodati u zvanicnu verziju
        /// </summary>

        #region Version 2.0

        public float GetMaxValue()  // beta za PVS
        {
            List<Move> potezi = MoguciPotezi();
            var max = potezi.OrderByDescending(x => x.Value);
            return max.First().Value;
        }

        public float GetMinValue()  // alfa za PVS
        {
            List<Move> potezi = MoguciPoteziProtivnika();
            var min = potezi.OrderBy(x => x.Value);
            return min.First().Value;
        }

        public List<Move> CART_DecisionTree()  // Stablo Odlucivanja CART algoritmom
        {
            return null;
        }


        #endregion

        #region Benchmark

        List<Karta> PodeliKarteIzSpila()
        {
            List<Karta> sve = new List<Karta>();
            Spil spil = new Spil();
            foreach(Karta karta in spil.Karte)
            {
                sve.Add(karta);
            }
            return sve;
        }

        public void StampajPreostaleKarte()
        {
            foreach(Karta karta in preostaleKarte)
            {
                Console.Write(karta.Broj + " " + karta.Boja + " | ");
            }
        }

        public void StampajTalon()
        {
            foreach(Karta karta in talon)
            {
                Console.Write(karta.Broj + " " + karta.Boja + " | ");
            }
        }

        public void StampajRuku(IgracAI igracAI)
        {
            SortirajRuku();
            Console.WriteLine("Igrac " + igracAI.Ime + " ima u ruci: ");
            foreach (Karta karta in ruka)
            {
                Console.Write(karta.Broj + " " + karta.Boja + " | ");
            }
            Console.WriteLine("");
        }

        #endregion
    }
}
